# Wczytaj do zmiennej text całą zawartość pliku 'plik.txt'.
text = File.read("plik.txt")
puts text

# Z tekstu zwróć linie (#lines) w postaci tablicy (#to_a), odwróc tablicę 
# (#reverse) i sklej linie z powrotem w tekst (#join).
reversed = text.lines.to_a.reverse.join

# Zapisz wynik do pliku o nazwie 'plik2.txt'
File.open("plik2.txt", 'w+') { |f| f.puts reversed }

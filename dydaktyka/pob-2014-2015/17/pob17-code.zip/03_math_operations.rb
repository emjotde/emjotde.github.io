# encoding: utf-8

a = 3
b = 2
c = -4.0

puts "a = #{a}, b = #{b}, c = #{c}"

puts "a+b = #{a + b}"
puts "a*b = #{a * b}"
puts "a^b = #{a ** b}"      # potęgowanie
puts "a%b = #{a % b}"

puts "a/b = #{a / b}"       # dzielenie dwóch liczb całkowitych zwraca liczbę
puts "a/c = #{a / c}"       # całkowitą
puts "a.to_f = #{a.to_f}"   # metoda #to_f zwraca liczbę zmiennoprzecinkową
puts "a/b.to_f = #{a / b.to_f}"

puts "a.zero? #{a.zero?}"   # znak zapytania oraz wykrzyknik mogą znajdować się w nazwie zmiennej
puts "a.even? #{a.even?}" 
puts "a.even? #{a.odd?}"

puts "abs(a) = #{c.abs}"    # wartość bezwzględna z liczby
puts "sqrt(a) = #{Math.sqrt(a)}"
puts "log(a) = #{Math.log(a)}"


puts "Task 04: division"
# Task 01: Oblicz i wypisz resztę z dzielenia przez 5 sumy liczb a, b i c.

puts "Task 05: percentage"
# Task 02: Oblicz i wypisz jaki procent sumy wartości bezwzględnych liczb a, b
#   i c stanowi liczba a.

puts "Task 06: delta"
# Task 03: Oblicz i wypisz deltę trójmianu o współczynnikach a, b i c.

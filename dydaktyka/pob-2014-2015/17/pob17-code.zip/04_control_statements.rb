# encoding: utf-8

zero = 0
one = 1

# alternatywne zapisy instrukcji if
if zero == 0
  puts "yes, 0 is 0!"
end

if zero == 0 then puts "yes, 0 is 0!" end

puts "yes, 0 is 0!" if zero == 0

# instrukcja if-else
if one == 0
  puts "yes?!"
else
  puts "no, 1 is not 0!"
end

# krótka instrukcja if
puts one == 0 ? "yes?!" : "no, 1 is not 0!"

# unless funkcjonuje jako 'if not'
unless one == 0
  puts "no, 1 is not 0!" 
end

puts "no, 1 is not 0!" unless one == 0

# tylko wartości false oraz nil są fałszem, reszta jest prawdą, łącznie z
# zerem!
puts "nil is false!" unless nil
puts "1 is true!" if 1 
puts "strings, numbers and other classes are true!" if "Ala ma kota"
puts "0 is true!" if 0 

# wszystkie instrukcje są również wyrażeniami, więc zwracają wartość z 
# ostatniej linii bloku
answer = if one == 0
           "yes?!"
         else
           "no, 1 is not 0!"
         end
puts answer

# Podstawowe pętle.
puts "3.times = "
3.times{ |i| puts i }

puts "9.downto(6) = "
9.downto(6){ |i| puts i }

puts "for loop = "
for i in 3..6 
  puts i
end

puts "while loop = "
number = 0
while number < 3
  number += 1
  puts number
end

puts "short while loop = "
number = 0
puts number += 1 while number < 3

ary = ['a', 'b', 'c', 'd']

# Do iterowania po elementach tablicy najczęściej wykorzystuje się metodę #each.
# Kod wewnątrz nawiasów klamrowych nazywany jest blokiem.
puts "ary.each{ |e| block } = "
ary.each{ |e| puts e }

# Zgodnie z konwencją zapis z do-end stosujemy dla wielolinijkowych bloków.
puts "ary.each do |e|... = " 
ary.each do |e|
  puts e
end

# Gdy potrzebny jest indeks elementu użyjemy metodę #each_with_index.
puts "ary.each_with_index{ |e,i| block } = "
ary.each_with_index{ |e,i| puts e*(i+1) }

# Jest również wiele innych wersji metody #each dla obiektów różnych klas.
str = "Ala i kot!"
puts "str.each_char{ |c| block } = "
str.each_char{ |c| puts c }

hsh = { 'A' => 1.0, 'B' => 2, 'C' => 'three' }

# Iterując po tablicach asocjacyjnych uzyskujemy dostęp do klucza i wartości.
puts "hsh.each do |k,v|... = "
hsh.each do |key, value|
  puts "#{key} -> #{value}"
end


# encoding: utf-8


s = "Ala"               # tekst może być zawarty między podwójnymi lub 
w = 'kota'              # pojedynczymi cudzysłowami

puts "s = #{s}"         # kod wewnątrz #{} jest wykonywany i zwracany jest 
puts 'w != #{w}'        # wynik wykonania, ale tylko w przypadku podwójnych 
                        # cudzysłowów

s = s + " ma "          # konkatenacja
puts s

puts "s<<w = #{s << w}" # dopisanie do końca łańcucha, alternatywnie można użyć 
                        # operatora +=
puts "w*3 = #{w * 3}"            
puts "s[0] = #{s[0]}"   # łańcuch znaków jest traktowany jako tablica, więc 
                        # uzyskujemy dostęp do pierwszego znaku

puts "s.empty? = #{s.empty?}"
puts "s.downcase = #{s.downcase}"
puts "s.upcase = #{s.upcase}"
puts "s.reverse = #{s.reverse}"
puts "s.include? 'a' = #{s.include? 'a'}"


name = "Jan Kowalski"

puts "Task 01: name"
# Task 01: Wypisz wartość zmiennej 'name' poprzedzoną napisem "name = ". Wynik
#   wypisz w jednej linii.

puts "Task 02: uppercased and reversed"
# Task 02: Wypisz wartość zmiennej 'name' powstałą po zamianie wszystkich liter
#   na duże i odwróceniu kolejności liter.

puts "Task 03: 'a' to 'e'"
# Task 03: Do zmiennej 'neme' przypisz wartość zmiennej 'name', w której litera
#   'a' będzie zastąpiona literą 'e'


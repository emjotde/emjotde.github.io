# encoding: utf-8

ary = [1, 2, 3, 4]                # stworzenie tablicy
puts "ary = #{ary}"               # wypisanie elementów tablicy

puts "ary.size = #{ary.size}"
puts "ary[0] = #{ary[0]}"       
puts "ary.first = #{ary.first}"
puts "ary[-1] = #{ary[-1]}"       # ostatni element
puts "ary[1..3] = #{ary[1..3]}"   # elementy od 1 do 3 włącznie

ary2 = [1, 'two', -3.0]           # tablica może przechowywać elementy dowolnego typu
ary2 << 4.0                       # dodanie elementu na koniec tablicy

txt = ary2.join(';')              # połączenie elementów znakiem średnika i zwrócenie tekstu
puts "ary2.join(';') = #{txt}" 

hsh = {                           # stworzenie tablicy asocjacyjnej
  'A' => 1, 
  'B' => 'two', 
  'C' => -3.0 
}
puts "hsh = #{hsh}"

puts "hsh.size = #{hsh.size}"
puts "hsh.keys = #{hsh.keys}"     # klucze jako tablica
puts "hsh.values = #{hsh.values}" # wartości jako tablica


list = [19, 5, 20, 15]

puts "Task 07: double second element"
# Task 01: Zwiększ drugi element listy dwukrotnie i wypisz całą listę

puts "Task 08: list variation"
# Task 02: Do listy dodaj dwukrotnie jej przed ostatni element i wypisz trzy
#   pierwsze elementy listy.

puts "Task 09: reversed number"
# Task 03: Wypisz liczbę powstałą przez odwrócenie kolejności połączenych
#   wszystkich elementów listy.

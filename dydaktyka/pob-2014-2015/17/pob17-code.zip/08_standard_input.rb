# encoding:utf-8

puts "Give me numbers (one number per line), press (q) to stop"
numbers = []

# Metoda #gets pobiera linię ze standardowego wejścia.
# #puts pisze  na standardowe wyjście.
# #chomp usuwa znaki specjalne z końca łańcucha znaków (jak znak nowej linii).
while line = gets.chomp
  break if line == 'q' 
  numbers << line.to_i
end


puts "Your numbers = #{numbers}"

puts "Task 10: max number"
# Task 01: Znajdź i wypisz największą z wczytanych liczb.

puts "Task 11: even numbers"
# Task 02: Znajdź i wypisz tylko liczby parzyste.

puts "Task 12: numbers * 2"
# Task 03: Wypisz dwukrotność każdej z wczytanych liczb.

puts "Task 13: numbers < 10"
# Task 04: Znajdź i wypisz liczby mniejsze od 10 spośród wczytanych liczb.

puts "Task 14: sum of numbers"
# Task 05: Znajdź i wypisz sumę wszystanych liczb.


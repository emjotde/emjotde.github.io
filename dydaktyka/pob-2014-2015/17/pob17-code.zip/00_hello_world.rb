# encoding: utf-8

# Metoda #puts wypisuje tekst na standardowe wyjście wraz ze znakiem nowej
# linii. Aby wypisać tekst bez złamania linii należy użyć metody #print.
puts "Hello World!"

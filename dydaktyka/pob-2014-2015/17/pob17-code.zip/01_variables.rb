# encoding: utf-8

text = "some text"        # zmienna przechowująca tekst
puts text

number = 14               # zmienna przechowująca liczbę całkowitą
puts number               # konwersja do String podczas wypisania

number = text             # zmienna może przechowywać wartość dowolnego typu
puts number == text
              
empty = nil               # zmienna "pusta" 
puts empty

CONSTANT = "constant"     # zmienna, której nazwa rozpoczyna się dużą literą to stała
CONSTANT = "other value"  # działa, ale interpreter zwróci ostrzeżenie

$global_var = 123         # zmienna rozpoczynająca się od $ to zmienna globalna

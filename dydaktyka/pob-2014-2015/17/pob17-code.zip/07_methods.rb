# encoding: utf-8

# Definicja metody przyjmującej dwa argumenty.
def simple_method(arg_one, arg_two)
  puts "simple method with arguments: #{arg_one} and #{arg_two}"
end

# Wywołanie metody.
simple_method(1, 2.0)

# Nawiasy otaczające argumenty w większości przypadków są opcjonalne.
simple_method 1, 2.0

# Argumenty mogą być dowolnego typu.
simple_method('Ala', [1, 2, 3])

# Drugi argument ma domyślną wartość, zatem możliwe jest użycie metody z jednym argumentem.
def method_with_default_argument(arg_one, arg_two='default value')
  puts "method with default argument: #{arg_one} and #{arg_two}"
end

method_with_default_argument(1, :two)
method_with_default_argument('passed value')

# Nazwy metod mogą zawierać również znaki ? oraz !.
def big_number?(number)
  return number > 1000
end

puts big_number?(1234)

# Każda metoda zwraca wartość - jest nią kod zawarty po słowie kluczowym return, 
# lub wartość z ostatniego wyrażenia w metodzie.
def find_next(value)
  return if value.nil?
  value.next                # tutaj słowo return jest opcjonalne!
end

a = find_next("it's oj")
puts a
puts find_next(123)
puts find_next(:still_oj)

puts find_next([1, 2, 3])   # uups, klasa Array nie ma metody #next

import java.io.*;

class ReadFile {
    public static void main(String args[]) throws Exception {
        FileReader fileReader = new FileReader("ReadFile.java");
        BufferedReader reader = new BufferedReader(fileReader);
        
        String line;
        while ((line = reader.readLine()) != null) {
            System.out.println(line);
        }
        
        fileReader.close();
    }
}

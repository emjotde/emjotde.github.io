public class CompareStrings {
    public static void main(String[] args) {
        String s1 = "Pietruszka";
        String s2 = "Pietr" + "uszka";
        String s3 = "Pietr";
        String s4 = "pietruszka";
        s3 += "uszka";
        
        System.out.println("Czy " + s1 + " = " + s2 + " ? "
            + (s1 == s2 ? "tak" : "nie"));
        System.out.println("Czy " + s1 + " = " + s3 + " ? "
            + (s1 == s3 ? "tak" : "nie"));
        System.out.println("Czy " + s1 + " equals " + s3 + " ? "
            + (s1.equals(s3) ? "tak" : "nie"));
        System.out.println("Czy " + s1 + " = " + s4 + " ? "
            + (s1 == s4 ? "tak" : "nie"));
    }
}

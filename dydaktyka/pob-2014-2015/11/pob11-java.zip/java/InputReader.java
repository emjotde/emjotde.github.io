import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class InputReader {
    public static void main(String[] args) throws IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        
        // wczytujemy string
        System.out.println("Jak masz na imie?");
        String name = input.readLine();

        // wczytujemy liczbe
        System.out.println("Ile masz lat?");
        int age = Integer.parseInt(input.readLine());

        System.out.println("Witaj " + (age < 18 ? "nie" : "") + "pełnoletni " + name + "!");
    }
}

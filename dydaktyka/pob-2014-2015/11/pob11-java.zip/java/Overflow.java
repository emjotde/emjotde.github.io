//: c03:Overflow.java
// From 'Thinking in Java, 2nd ed.' by Bruce Eckel
// www.BruceEckel.com. See copyright notice in CopyRight.txt.
// Surprise! Java lets you overflow.

public class Overflow {
    public static void main(String[] args) {
        int big = Integer.MAX_VALUE; // max int value
        System.out.println("big = " + big);
        int bigger = big * 4;
        System.out.println("bigger = " + bigger);
    }

} // /:~

public class Arrays {
    public static void main(String[] args) {

        System.out.println("Kopiowanie naiwne:");

        int[] a = {1, 2, 3};    // inicjalizacja tablicy
        int[] b = a;            // kopiuje sie tylko referencja

        b[0] = -1;
        printArrays(a, b, a.length);
        
        System.out.println("Kopiowanie ręczne:");

        int[] c = new int[a.length];
        for (int i = 0; i < a.length; ++i) {
            c[i] = a[i];
        }

        c[0] = -2;
        printArrays(a, c, a.length);
    
        System.out.println("Kopiowanie z użyciem biblioteki:");

        int[] d = java.util.Arrays.copyOf(a, a.length);
        d[0] = -3;

        printArrays(a, d, a.length);
    }

    public static void printArrays(int[] a, int[] b, int size) {
        for (int i = 0; i < size; ++i) {
            System.out.println("a[" + i + "] = " + a[i] + "\t" + "b[" + i + "] = " + b[i]);
        }
    }
} 

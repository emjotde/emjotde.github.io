public class Array {
    
    public static void main(String[] args) {
        int[] array = new int[10];
        
        for (int i = 0; i < array.length; i++) {
            array[i] = 5 - i;
            System.out.println("array[" + i + "] = " + array[i]);
        }

        int maximum = 0;

        for (int i = 0; i < array.length; i++) {
            if (maximum < array[i]) {
                maximum = array[i];
            }
        }

        System.out.println("Maximum: " + maximum);
    }
}

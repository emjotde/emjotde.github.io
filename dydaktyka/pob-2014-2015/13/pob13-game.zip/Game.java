public class Game {

    public static void main(String[] args) {
        int points1 = 0, points2 = 0;
        
        for (int i = 1; i <= 10; ++i) {
            /*
            // zadanie 04
            Move move1 = Move.getRandom(), move2 = Move.getRandom();
      
            System.out.println("Round " + i);
            System.out.println("Player 1: " + move1);
            System.out.println("Player 2: " + move2);
            */

            /*
            // zadanie 05
            if (move1.beats(move2)) {
                System.out.println("Player 1 wins!");
                ++points1;
            }
            else if (move2.beats(move1)) {
                System.out.println("Player 2 wins!");
                ++points2;
            }
            else {
                System.out.println("Draw!");
            }
      
            System.out.println("Result: " + points1 + "-" + points2 + "\n");
            */
        }
    }
}

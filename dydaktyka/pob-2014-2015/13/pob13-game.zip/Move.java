public class Move {
    public boolean beats(Move move) { 
      return true; 
    }
}
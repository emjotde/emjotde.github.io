public class Paper extends Move {
}
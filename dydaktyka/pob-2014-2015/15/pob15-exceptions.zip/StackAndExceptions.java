class Stack {
    private String[] elements;
    private int n;
    
    public Stack(int maxSize) {
        elements = new String[maxSize];
        n = 0;
    }

    public boolean empty() {
        return n == 0;
    }

    public void push(String element) {
        elements[n++] = element;
    }

    public String pop() {
        return elements[--n];
    }
}

public class StackAndExceptions {
    public static void main (String [] args) {
        Stack stack = new Stack(3);

        for (String arg: args) {
            System.out.println("Add: " + arg);
            stack.push(arg);
        }
         
        System.out.println("Stack:");
        while (! stack.empty()) {
            System.out.println(stack.pop());
        }
    }
}

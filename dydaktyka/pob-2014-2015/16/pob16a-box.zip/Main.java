public class Main {
    public static void main (String [] args) {
        Box box = new Box(3);
        box.add(5);
        box.add(10);
        box.add(15);
        System.out.println(box);
    }
}

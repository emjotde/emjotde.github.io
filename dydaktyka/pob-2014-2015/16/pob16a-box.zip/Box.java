import java.util.Arrays;

public class Box {
    private int[] elements;
    private int maxSize = 0;
    private int n = 0;

    String name = "My own box";
    static int boxes = 0;


    public Box(int size) {
        maxSize = size;
        elements = new int[maxSize];
        ++boxes;
    }

    public void add(int element) {
        elements[n++] = element;
    }

    public int get(int i) {
        return elements[i];
    }

    public int size() {
        return elements.length;
    }

    public String toString() {
      return "Box (" + size() + "/" + maxSize + "): " + Arrays.toString(elements);
    }
}

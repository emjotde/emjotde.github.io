import javax.swing.*;

import java.awt.Dimension;
import java.awt.Color;

public class HelloWorldSwing {
    /**
     * Stworzy i wyświetla interfejs użytkownika.
     */
    private static void createAndShowGUI() {
        // Tworzy formatkę z tytułem 'Hello World' i ustawia przycisk krzyżyk
        // na belce jako zamykający.
        JFrame frame = new JFrame("Hello World");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Ustawia początkowy rozmiar okna
        frame.setPreferredSize(new Dimension(250,150));

        // Tworzy etykietę z tekstem i umieszcza ją na formatce.
        JLabel label = new JLabel("Hello World from Swing!");
        frame.getContentPane().add(label);

        // Wyświetla okno.
        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        // Kolejkuje zadanie, którym jest stworzenie i wyświetlenie okna.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }
}

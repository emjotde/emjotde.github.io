import java.util.List;
import java.util.Arrays;

public class UglyLengthConverter {
    public final static List<String> UNITS = Arrays.asList("m", "cm", "km", "mi", "ft");
    private final static List<Double> meterFactors = Arrays.asList(1.0, 0.01, 1000.0, 1609.34, 0.3);

    public static Double convert(Double value, String fromUnit, String toUnit) {
        if (UNITS.contains(fromUnit) && UNITS.contains(toUnit))
            return convertFromMeters(convertToMeters(value, fromUnit), toUnit);
        return Double.NaN;
    }

    static Double convertToMeters(Double value, String unit) {
        return value * meterFactors.get( UNITS.indexOf(unit) );
    }
    static Double convertFromMeters(Double value, String unit) {
        return value / meterFactors.get( UNITS.indexOf(unit) );
    }

    /*
    public static void main(String[] args) {
        Double d = convert(Double.parseDouble(args[0]), args[1], args[2]);
        System.out.println(d);
    }
    */
}

#include <iostream>

const int MAX = 100;

class Stack {
  public:
    int n;          // aktualna liczba elementów na stosie
    int data[MAX];  // tablica przechowująca elementy
    
    /*
     * w tym miejscu dodaj definicje metod: 
     *  - void init 
     *  - int pop 
     *  - void push 
     *  - bool empty
     */
};

int main() {
  Stack s;          // utworzenie obiektu
  
  // w tym miejscu dodaj inicjalizację obiektu (init) 
  // w tym miejscu dodaj kilka elementów na stos (push)
  // w tym miejscu wypisz wszystkie elementy (pop i empty)

  return 0;
}

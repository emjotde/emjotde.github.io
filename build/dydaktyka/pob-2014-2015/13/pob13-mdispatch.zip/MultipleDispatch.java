/*
 * Z klasy MyValue dziedziczą dwie klasy:
 *  * MyNumber - reprezentuje liczbę
 *  * MyString - reprezentuje łańcuch znaków
 *
 * Chcemy mieć możliwość sprawdzenia, który z dwóch obiektów dowolnego z 
 * powyższych dwóch typów jest mniejszy. Możliwe są cztery sytuacje:
 *
 *  * myNumber < myNumber - porównujemy liczby
 *  * myString < myNumber - sprawdzamy czy długość myString w znakach jest 
 *                          mniejsza niż liczba myNumber
 *  * myNumber < myString - jw.
 *  * myString < myString - porównujemy długości w znakach
 *
 * Porównanie będzie realizować metoda isSmaller(MyValue other). Metoda ta 
 * zachowywać będzie się inaczej w zależności od tego, jakiej klasy jest 
 * obiekt other. W klasycznym podejściu można wykorzystać operator instanceof, 
 * jednak można również napisać własną implementację mechanizmu multimetod.
 * 
 * Porównanie do prawidłowego działania wymaga informacji o typach dwóch 
 * obiektów. Wywołanie metody isSmaller() powoduje oddelegowanie do 
 * odpowiedniej metody z obiektu przekazanego jako argument, w nazwie której
 * zawarta jest również informacja o typie jednego z tych obiektów. 
 * Drugi typ obiektu jest oczywisty, gdyż jest to klasa, na rzecz której 
 * metoda została wywołana.
 *
 * Np. mając metodę isBiggerThanMyString() w klasie MyNumber, wiadomo już, że 
 * jest to porównanie MyString oraz MyNumber.
 *
 */

abstract class MyValue {
    abstract boolean isSmaller(MyValue other);
    abstract boolean isBiggerThanMyNumber(MyNumber myNumber);
    abstract boolean isBiggerThanMyString(MyString myString);
}

class MyNumber extends MyValue {
    Integer value;
    MyNumber(int number) {
        this.value = number;
    }

    // metoda porównująca obiekty
    boolean isSmaller(MyValue other) {
        return other.isBiggerThanMyNumber(this);
    }

    boolean isBiggerThanMyNumber(MyNumber myNumber) {
        return this.value > myNumber.value;
    }
    boolean isBiggerThanMyString(MyString myString) {
        return this.value > myString.value.length();
    }

    // ułatwienie wypisywania
    public String toString() {
        return value.toString();
    }
}

class MyString extends MyValue {
    String value;
    MyString(String string) {
        this.value = string;
    }

    // metoda porównująca obiekty
    boolean isSmaller(MyValue other) {
        return other.isBiggerThanMyString(this);
    }

    boolean isBiggerThanMyNumber(MyNumber myNumber) {
        return this.value.length() > myNumber.value;
    }
    boolean isBiggerThanMyString(MyString myString) {
        return this.value.length() > myString.value.length();
    } 

    // ułatwienie wypisywania
    public String toString() {
        return value;
    }
}

public class MultipleDispatch {
    public static void main(String[] args) {
        MyValue[] values = {
            new MyNumber(5),
            new MyNumber(15),
            new MyString("ala"),
            new MyString("makota")
        };

        // każdy z każdym oprócz identycznych obiektów
        for (MyValue v1: values) {
            for (MyValue v2: values) {
                if (v1 == v2) 
                    continue;
                System.out.println(v1 + " < " + v2 + ":\t " + v1.isSmaller(v2));
            }
        }
    }
}
